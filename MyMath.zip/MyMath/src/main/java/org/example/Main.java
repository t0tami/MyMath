package org.example;

import static org.example.first.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("Первое задание: ");
        System.out.println("Pi: " + PI);
        System.out.println("E: "+ E);
        int num = 5;
        int num1 = 10;
        System.out.println("Максимальное число: "+ getMax(num , num1));

        double num2 = 34.56;
        double num3 = 23.09;

        System.out.println("Максимальное число: "+ getMax((int )num2, (int) num3));




        }
    }
