package org.example;

public class second {
}
