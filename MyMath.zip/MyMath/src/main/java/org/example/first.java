package org.example;
import java.util.Scanner;
public class first {
    Scanner scr = new Scanner(System.in);
    public static final double PI = Math.PI;
    public static final double E = Math.E;

    public static int getMax(int a,int b){
        if (a>b){
            return a;
        }else{
            return b;
        }
    }

}
